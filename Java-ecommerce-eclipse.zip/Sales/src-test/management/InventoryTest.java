package management;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

import saleable.Clothing;
import saleable.Product;
import saleable.Shoes;

public class InventoryTest {
	

	 private Inventory inventoryTest;
	    private Product tshirt;
	    private Product jeans;
	    private Product trainers;
	    private Product sandals;
	    
	@BeforeEach
	public void setUp() {
		// Initialise a fresh inventory and products before each test
		this.inventoryTest = new Inventory();
		this.tshirt = new Clothing(2000, 300, "Stripe long-sleeved", 10, "Black and white stripe");
		this.jeans = new Clothing(3500, 800, "Straight-cut", 12, "Light blue");
		this.trainers = new Shoes(5000, 1200, "Tennis shoes", 37, "No heel");
		this.sandals = new Shoes(4000, 900, "Beach sandals", 38, "Flats");
	}
	
	@Test
	public void testEmptyInventory() {
		
		// Check inventory before adding any items to it
		assertEquals(0, inventoryTest.getQuantity(tshirt));
		assertEquals(0, inventoryTest.getQuantity(jeans));
	}
	
	
	@Test
	public void testAddStock() {
		
		// Add stock to inventory
		inventoryTest.addStock(tshirt, 10);
		assertEquals(10, inventoryTest.getQuantity(tshirt));
		// Add more stock to existing item in inventory
		inventoryTest.addStock(tshirt, 5);
		assertEquals(15, inventoryTest.getQuantity(tshirt));
		// Add new stock to inventory
		inventoryTest.addStock(sandals, 25);
		assertEquals(25, inventoryTest.getQuantity(sandals));
		
	}
	
	
	@Test 
	public void testRemoveStock() {

		// Add stock to inventory
		inventoryTest.addStock(jeans, 10);
		assertEquals(10, inventoryTest.getQuantity(jeans));
		// Remove portion of stock
		inventoryTest.removeStock(jeans, 5);
		assertEquals(5, inventoryTest.getQuantity(jeans));
		// Remove all remaining stock
		inventoryTest.removeStock(jeans, 5);
		assertEquals(0, inventoryTest.getQuantity(jeans));
		
	}
	
	
	@Test
	public void testRemoveStockFailure() {

		// Add stock to inventory
		inventoryTest.addStock(trainers, 10);
		assertEquals(10, inventoryTest.getQuantity(trainers));
		// Attempting to remove more than available throws illegal argument exception
		Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            inventoryTest.removeStock(trainers, 15);
        });
		// Confirm illegal argument exception contains message saying stock cannot be negative
		assertTrue(exception.getMessage().contains("Stock cannot go below 0"));
		// Confirm stock levels remain the same
		assertEquals(10, inventoryTest.getQuantity(trainers));
		// Remove all remaining stock and confirm quantity is 0
		inventoryTest.removeStock(trainers, 10);
		assertEquals(0, inventoryTest.getQuantity(trainers));
		// Removing stock from quantity 0 throws illegal argument exception
		Exception exception2 = assertThrows(IllegalArgumentException.class, () -> {
            inventoryTest.removeStock(trainers, 5);
        });
		// Confirm illegal argument exception contains message saying stock cannot be negative
		assertTrue(exception2.getMessage().contains("Stock cannot go below 0"));
		// Confirm quantity unchanged
		assertEquals(0, inventoryTest.getQuantity(trainers));
	}
	
	
	
}
