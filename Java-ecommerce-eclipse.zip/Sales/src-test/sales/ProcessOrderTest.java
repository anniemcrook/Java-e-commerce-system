package sales;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import management.Inventory;
import saleable.Product;
import saleable.Shoes;

public class ProcessOrderTest {

	 private Inventory testInventory;
	 private Product trainers;
	 private Customer c5;
	 private ProcessOrder order;
	 private ProcessOrder refund;

	 @BeforeEach
	 public void setUp() {
		// Initialise a fresh inventory and products before each test
		this.c5 = new Customer("EFG");
		this.testInventory = new Inventory();
		this.trainers = new Shoes(3700, 1100, "Canvas trainers", 36, "flat");
		testInventory.addStock(trainers, 10);
		this.order = new ProcessOrder(); 
		this.refund = new ProcessOrder();
		}
	    
	@Test
	public void testProcessOrder() {
		// Test a purchase with processOrder
		order.processOrder(c5, trainers, 1, testInventory);
		assertEquals(3910, c5.getTotal()); // Price of trainers plus the calculated delivery
	}
	
	@Test
	public void testProcessRefund() {
		// Test a refund with processRefund
		refund.processRefund(c5, trainers, 1, testInventory, trainers.getPrice(), "Too big");
		assertEquals(-3700, c5.getTotal()); // Price of trainers refunded (negative)
	}
}
