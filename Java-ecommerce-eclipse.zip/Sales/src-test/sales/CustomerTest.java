package sales;

import static org.junit.Assert.*;
import org.junit.Test;

import saleable.Clothing;
import saleable.Service;
import saleable.Shoes;
import transaction.Purchase;
import transaction.Refund;

public class CustomerTest {

	@Test
	public void testCustomerWithoutPurchase() { 
		//testing a customer with no transactions
		Customer c1 = new Customer("ABC");
		assertEquals(0, c1.getTotal());		
	}
	
	@Test
	public void testCustomerWithPurchase() {		
		//testing a customer with only purchase transactions
		Customer c2 = new Customer("BCD");
		Clothing tshirt = new Clothing(1500, 170, "Simple V-neck", 8, "black");
		Purchase p1 = new Purchase(tshirt, 2);
		c2.transact(p1);
		Service s1 = new Service(350, "Gift Wrap");
		Purchase p2 = new Purchase(s1, 1);
		c2.transact(p2);
		assertEquals(3384, c2.getTotal());
	}
	
	@Test
	public void testCustomerWithRefund() {
		//testing a customer with only refund transactions
		Customer c3 = new Customer("CDE");
		Refund r1 = new Refund(2900, "too small");
		c3.transact(r1);
		assertEquals(-2900, c3.getTotal());
	}
	
	@Test
	public void testCustomerWithPurchaseAndRefund() {
		//testing a customer with both purchase and refund transactions
		Customer c4 = new Customer("DEF");
		Clothing jeans = new Clothing(3500, 750, "Mom Fit", 10, "Acid wash blue");
		Purchase p2 = new Purchase(jeans, 1);
		c4.transact(p2);
		Shoes sandals = new Shoes(4500, 1400, "Strappy sandals", 39, "flat");
		Purchase p3 = new Purchase(sandals, 2);
		c4.transact(p3);
		Service s2 = new Service(500, "Express Delivery");
		Purchase p4 = new Purchase(s2, 1);
		c4.transact(p4);
		Refund r2 = new Refund(4500, "too tight");
		c4.transact(r2);
		assertEquals(8890, c4.getTotal());
	}
	
	
	
}
