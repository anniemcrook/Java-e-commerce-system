package saleable;

/**
 * GiftWrap class represents a gift wrapping service.
 */
public class GiftWrap extends Service {
	
	/**
	 * The constructor initialises a gift wrapping service object with a price and a name.
	 * @param price The price for the chosen gift wrapping option.
	 * @param name The name of the chosen gift wrapping option.
	 */
	public GiftWrap(int price, String name) {
		super(price, name);
	}

}
