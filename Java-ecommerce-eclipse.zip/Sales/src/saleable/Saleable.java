package saleable;

/**
 * This class represents items to be sold.
 * The interface sets up the blueprint for the Products and Services classes.
 */
public interface Saleable {

	/**
	 * The getPrice method returns the price of the item.
	 * The price will vary based on the Product or Service.
	 * @return The price of the item in pennies.
	 */
	public int getPrice();
	
	/**
	 * The getName method returns the name of the item.
	 * The name will vary based on the Product or Service.
	 * @return The name of the item.
	 */
	public String getName();
	
}
