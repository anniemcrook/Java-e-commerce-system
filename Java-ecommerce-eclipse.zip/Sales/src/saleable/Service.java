package saleable;

/**
 * The Service class represents a Service that can be bought.
 * This class implements the Saleable interface.
 */
public class Service implements Saleable {
	
	/**
	 * The price of the service in pennies.
	 */
	private int price;
	/** 
	 * The name of the service.
	 */
	private String name;
	
	/**
	 * The constructor initialises a Service with a price and a name.
	 * @param price The price of the Service.
	 * @param name The name of the Service.
	 */
	public Service(int price, String name) {
		this.price = price;
		this.name = name;
		}

	/**
	 * The getPrice method returns the price of the Service.
	 * @return Returns the price of the Service.
	 */
	public int getPrice() {
		return price;
	}
	
	/**
	 * The getName method returns the name of the Service.
	 * @return Returns the name of the Service.
	 */
	public String getName() {
		return name;
	}


}