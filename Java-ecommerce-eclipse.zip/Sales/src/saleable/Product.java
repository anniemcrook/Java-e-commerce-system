package saleable;

/**
 * The Product class provides the 
 */
public class Product implements Saleable {

	/**
	 * The price is in pennies.
	 */
	private int price; //in pennies
	/**
	 * The weight is in grams.
	 */
	private int weight; //in grams
	/**
	 * The name of the product.
	 */
	private String name;
	/**
	 * The size is in standard numerical UK women's clothing sizes (8, 10, 12, etc).
	 */
	private int size;
	
	/**
	 * The constructor initialises a Product object with a price in pennies, weight in grams,
	 * a name, and size.
	 * @param price The price of the Product in pennies.
	 * @param weight The weight of the Product in grams.
	 * @param name The name of the Product.
	 * @param size The size of the Product.
	 */
	public Product(int price, int weight, String name, int size) {
		this.price = price;
		this.weight = weight;
		this.name = name;
		this.size = size;
		}
	
	/**
	 * The getPrice method returns the price of the Product.
	 * @return The price of the Product.
	 */
	public int getPrice() {
		return price;
	}
	
	/**
	 * The getWeight method returns the weight of the Product.
	 * @return The weight of the Product.
	 */
	public int getWeight() {
		return weight;
	}
	
	/**
	 * The getName method returns the name of the Product.
	 * @return The name of the Product.
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * The getSize method returns the size of the Product.
	 * @return The size of the product.
	 */
	public int getSize() {
		return size;
	}
	
	/**
	 * The calculateDelivery method calculates the cost of delivery based on the weight
	 * of the object.
	 * Items under 100 grams incur no delivery fee.
	 * Items over 100 grams but under 1000 grams incur a fee that is 20% of the weight.
	 * Items over 1000 grams incur a fee that is 20% of the first 1000 grams, and 10% of any
	 * weight above 1000 grams.
	 * @return The cost of delivery.
	 */
	public int calculateDelivery() {
		// Method calculates delivery fee based on weight
		int delivery = 0;
		if (weight < 100) {
			delivery = 0;
		} else if (weight >= 100 && weight < 1000) {
			delivery = (int)(weight * 0.20); // 20% of weight
		} else if (weight >= 1000) {
			delivery = (int)(1000 * 0.20) + (int)((weight - 1000) * 0.10); // 20% of first 1000, plus 10% of weight over 1000 grams
		}
		return delivery;
	}

}
