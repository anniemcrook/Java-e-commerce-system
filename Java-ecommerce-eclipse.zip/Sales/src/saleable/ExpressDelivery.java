package saleable;

/**
 * The ExpressDelivery class represents an express delivery service option.
 * ExpressDelivery extends Service class.
 */
public class ExpressDelivery extends Service {
	
	/**
	 * The fixedPrice field stores the fixed price of express delivery and cannot be changed.
	 */
	private static final int fixedPrice = 1000;

	/**
	 * The constructor initialises an ExpressDelivery object with price fixed at 1000 pennies.
	 * @param name The name of the service.
	 */
	public ExpressDelivery(String name) {
		super(fixedPrice, name);
	}

}
