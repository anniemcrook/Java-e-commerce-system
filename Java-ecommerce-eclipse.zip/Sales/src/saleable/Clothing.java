package saleable;

/**
 * The Clothing class represents an item of clothing.
 * Extends Product class.
 */
public class Clothing extends Product {
	
	/**
	 * The colour of the clothing product.
	 */
	private String colour;

	/**
	 * The constructor initialises a clothing object with a price, weight, name, size,
	 * and colour.
	 * @param price The price of the clothing item in pennies.
	 * @param weight The weight of the clothing item in grams.
	 * @param name The name of the clothing item.
	 * @param size The size of the clothing item in numerical sizes.
	 * @param colour The colour of the clothing item.
	 */
	public Clothing(int price, int weight, String name, int size, String colour) {
		super(price, weight, name, size);
		this.colour = colour;
	}
	
	/**
	 * The getColour method returns the colour of an item of clothing.
	 * @return The colour of the clothing.
	 */
	public String getColour() {
		return colour;
	}

}
