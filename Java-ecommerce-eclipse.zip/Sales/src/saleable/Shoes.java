package saleable;

/**
 * The Shoes class represents Shoes for sale.
 * Extends Product class.
 */
public class Shoes extends Product {

	/**
	 * Describes the height or style of the type of heel, i.e. flat, kitten, high, wedge.
	 */
	private String heel;
	
	/**
	 * The constructor initialises a pair of shoes Product with a price, weight in grams, 
	 * a name, shoe size, and heel height.
	 * @param price The price of the shoes.
	 * @param weight The weight of the shoes.
	 * @param name The name of the shoes.
	 * @param size The size of the shoes.
	 * @param heel The height of the shoes.
	 */
	public Shoes(int price, int weight, String name, int size, String heel) {
		super(price, weight, name, size);
		this.heel = heel;
	}

	/**
	 * the getHeelHeight method returns the type of heel of the shoes.
	 * @return Returns the type of heel.
	 */
	public String getHeel() {
		return heel;
	}
}
