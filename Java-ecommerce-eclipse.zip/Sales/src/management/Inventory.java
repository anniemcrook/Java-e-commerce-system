package management;

import java.util.HashMap;
import java.util.Map;

import saleable.Product;

/**
 * The Inventory class simulates an Inventory of all Products and their quantities.
 */
public class Inventory {

	/**
	 * The Product and quantity data is stored in a HashMap for fast access.
	 */
	private HashMap<Product, Integer> stock;
	
	/**
	 * The constructor initialises the HashMap.
	 * Constructs a new, empty Inventory instance.
	 */
	public Inventory() {
		stock = new HashMap<Product, Integer>();
	}
	
	/**
	 * The addStock method adds a Product and an integer quantity of said Product
	 * to the HashMap, or increases the stock of an existing Product in the 
	 * inventory.
	 * @param product The Product to be added to the Inventory.
	 * @param quantity The quantity of the product to be added.
	 */
	public void addStock(Product product, int quantity) {
		System.out.println("Adding " + quantity + " of " + product.getName() + " to stock.");
		stock.put(product, stock.getOrDefault(product, 0) + quantity);
	}
	
	/**
	 * The removeStock method removes stock from the Inventory.
	 * This method is called when a purchase is made.
	 * @param product The Product to be removed from the Inventory.
	 * @param quantity The quantity of the Product to be removed.
	 * @throws IllegalArgumentException if the quantity to be removed would take the 
	 * Product stock below zero.
	 */
	public void removeStock(Product product, int quantity) {
		int currentQuantity = stock.getOrDefault(product, 0); //check current stock levels
		int newQuantity = currentQuantity - quantity; //calculate new stock levels
		if (newQuantity < 0) {
			//if removing this quantity would make stock negative, throw illegal argument exception
			throw new IllegalArgumentException("Not enough stock remaining. Only " + currentQuantity + " units available. Stock cannot go below 0");
		} else {
			//otherwise update stock with new quantity, including 0
			System.out.println("Removing " + quantity + " of " + product.getName() + " from stock.");
			stock.put(product, newQuantity);
		}
	}
	
	/**
	 * The getQuantity method returns the current quantity of a Product.
	 * @param product The Product to be counted.
	 * @return The current quantity of the Product.
	 */
	public int getQuantity(Product product) {
		return stock.getOrDefault(product, 0);
	}
	
	/**
	 * The isAvailable method checks if the input quantity of the Product exists 
	 * in the Inventory.
	 * @param product The Product to be checked.
	 * @param quantity The quantity needed.
	 * @return True if the entered quantity is available; otherwise False.
	 */
	public boolean isAvailable(Product product, int quantity) {
		int availableQuantity = getQuantity(product);
		if (availableQuantity >= quantity) {
			System.out.println(availableQuantity + " of " + product.getName() + " in stock.");
			return true;
		} else {
			System.out.println(quantity + " of " + product.getName() + " is not currently in stock.");
			return false;
		}
	}
	
	/**
	 * The method displayInventory prints all Products and current quantities.
	 */
	public void displayInventory() {
		System.out.println("\n------Current Inventory Stock------");
		if (stock.isEmpty()) {
			System.out.println("Inventory is empty");
		} else {
			for (Map.Entry<Product, Integer> entry : stock.entrySet()) {
				Product product = entry.getKey();
				Integer quantity = entry.getValue();
				System.out.println("Product: " + product.getName() + ", Stock: " + quantity);
			}
		}
	}
	
	
}
