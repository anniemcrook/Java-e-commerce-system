package management;

import java.util.ArrayList;
import java.util.List;

import saleable.Saleable;
/**
 * The Catalogue class sets up a catalogue of products and services (items)
 */
public class Catalogue {

	/**
	 * The products and services are stored in a List of Saleable items
	 */
	private List<Saleable> items;
	
	/**
	 * The constructor initialises the ArrayList
	 */
	public Catalogue() {
		this.items = new ArrayList<Saleable>();
	}
	
	/**
	 * The getItems method returns a List of items in the Catalogue.
	 * @return Returns a List of items in the Catalogue.
	 */
	public List<Saleable> getItems() {
		return items;
	}
	
	/**
	 * The addItem method adds items to the Catalogue
	 * @param item The Product or Service to be added to the Catalogue
	 */
	public void addItem(Saleable item) {
		items.add(item);
	}
	
	/**
	 * The displayCatalogue method prints all the items added to the Catalogue
	 */
	public void displayCatalogue() {
		System.out.println("\n---Annie's Catalogue---");
		for (int i = 0; i < items.size(); i++) {
			System.out.println("Name: " + items.get(i).getName() + " -- Price: £" + (double)items.get(i).getPrice() / 100);
		}
	}
}
