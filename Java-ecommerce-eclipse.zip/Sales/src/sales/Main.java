package sales;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.UUID;

import management.Catalogue;
import management.Inventory;
import saleable.Clothing;
import saleable.ExpressDelivery;
import saleable.GiftWrap;
import saleable.Product;
import saleable.Saleable;
import saleable.Shoes;
import transaction.Purchase;
import transaction.Transaction;

/**
 * The Main class serves as the entry point for this interactive e-commerce application,
 * designed primarily for **store employees or owners**. This command-line interface
 * allows for the demonstration and management of core online shopping functionalities,
 * including inventory control, catalogue display, customer transactions, and order
 * processing (for both purchases and refunds).
 */
public class Main {

	// Static instances for shared resources across the application
		private static Inventory myInventory = new Inventory();
		private static Catalogue myCatalogue = new Catalogue();
		private static ProcessOrder order = new ProcessOrder(); //customer, product, quantity, stock
		private static Map<String, Customer> customers = new HashMap<>();
		private static Scanner scanner = new Scanner(System.in);
			
	/**
	 * The main method serves as the entry point for this e-commerce application.
	 * It demonstrates the interactive demonstration of internal store operations,
	 * including inventory, catalogue, customer, and order processing functions.
	 * @param args Command-line arguments passed to the program.
	 */
	public static void main(String[] args) {
		
		
		// Setup - populate Inventory and Catalogue
		System.out.println("---------Preparing Store---------");
		setupInitialData();
		
		
		// Main application
		
		int choice;
		do {
			displayMainMenu();
			choice = getUserChoice();
			
			switch (choice) {
			case 1:
				myCatalogue.displayCatalogue();
				break;
			case 2:
				myInventory.displayInventory();
				break;
			case 3:
				addStockToInventory();
				break;
			case 4:
				makePurchase();
				break;
			case 5:
				processRefund();
				break;
			case 6:
				viewCustomerTransactions();
				break;
			case 0:
				System.out.println("\nExiting application. Thank you for visiting Annie's Boutique!");
				break;
			default:
				System.out.println("\nInvalid choice. Please enter a number between 0 and 6");
			}
			System.out.println("\nPress Enter to continue...");
            scanner.nextLine(); // Consume the newline character after reading int
		}
		while (choice != 0);
		
		scanner.close();
	}	
	
	/**
	 * The setupInitialData method is a space for creating instances of all the products to be added to the store, populating the catalogue, and stocking
	 * the inventory.
	 */
	public static void setupInitialData() {
		// Create products
				Product BlackTShirt = new Clothing(2500, 200, "Black T-shirt", 8, "black");
				Product WhiteTShirt = new Clothing(2500, 200, "White T-shirt", 8, "black");
				Product AcidMomJeans = new Clothing(4500, 1200, "Acid Wash Mom jeans", 10, "Acid wash");
				Product GreyMomJeans = new Clothing(4500, 1200, "Grey Mom jeans", 10, "Light grey");
				Product GreyHoodie = new Clothing(3300, 800, "Grey Marle Hoodie", 10, "Grey marle");
				Product NavyHoodie = new Clothing(3300, 800, "Navy Hoodie", 10, "Navy");
				Product trainers38 = new Shoes(5500, 1000, "Running Shoes size 38", 38, "No heel");
				Product trainers39 = new Shoes(5500, 1000, "Running Shoes size 39", 39, "No heel");
				Product PartyShoes = new Shoes(4000, 1500, "Party shoes", 38, "3-inch heels");
				Product flatSandals = new Shoes(4000, 1500, "Sandals", 39, "flat");
				
				// Stock inventory
				myInventory.addStock(BlackTShirt, 45);
				myInventory.addStock(WhiteTShirt, 50);
				myInventory.addStock(AcidMomJeans, 40);
				myInventory.addStock(GreyMomJeans, 45);
				myInventory.addStock(GreyHoodie, 25);
				myInventory.addStock(NavyHoodie, 30);
				myInventory.addStock(trainers38, 8);
				myInventory.addStock(trainers39, 4);
				myInventory.addStock(PartyShoes, 5);
				myInventory.addStock(flatSandals, 4);
				
				// Create services
				int standard = 200;
				int special = 400;
				ExpressDelivery exDel = new ExpressDelivery("Next Day Delivery");
				GiftWrap standardWrap = new GiftWrap(standard, "Standard wrapping");
				GiftWrap birthdayWrap = new GiftWrap(special, "Birthday wrapping");
				GiftWrap anniversaryWrap = new GiftWrap(special, "Anniversary wrapping");
				
				// Populate Catalogue
				myCatalogue.addItem(BlackTShirt);
				myCatalogue.addItem(WhiteTShirt);
				myCatalogue.addItem(AcidMomJeans);
				myCatalogue.addItem(GreyMomJeans);
				myCatalogue.addItem(GreyHoodie);
				myCatalogue.addItem(NavyHoodie);
				myCatalogue.addItem(trainers38);
				myCatalogue.addItem(trainers39);
				myCatalogue.addItem(PartyShoes);
				myCatalogue.addItem(flatSandals);
				myCatalogue.addItem(exDel);
				myCatalogue.addItem(standardWrap);
				myCatalogue.addItem(birthdayWrap);
				myCatalogue.addItem(anniversaryWrap);
	}
	
	/**
	 * The displayMainMenu method displays the main menu for the program that will be used by an employee or the
	 * owner of the store to process orders (purchases and refunds), and to update the stock and catalogue.
	 */
	private static void displayMainMenu() {
		System.out.println("\n---------Annie's Boutique---------");
		System.out.println("1. View Catalogue");
		System.out.println("2. View Current Inventory Stock");
		System.out.println("3. Add new Stock/Re-stock Inventory");
		System.out.println("4. Make a Purchase");
		System.out.println("5. Process a Refund");
		System.out.println("6. View Customer transactions");
		System.out.println("0. Exit");
		System.out.println("Enter your choice: ");
	}
	
	/**
	 * The getUserChoice method is a helper method when accepting user input in the form of integer entry. The method 
	 * helps ensure that the user enters a valid integer value. In the case the user enters an invalid character,
	 * they are prompted again to enter a whole number.
	 * @return If user input is valid; returns user input as choice. Otherwise, returns -1.
	 */
	private static int getUserChoice() {
		if (scanner.hasNextInt()) {
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume the leftover newline character after reading the int
            return choice;
        } else {
            System.out.println("Invalid input. Please enter a number.");
            scanner.nextLine(); // Consume the invalid input to prevent infinite loop
            return -1; // Indicate invalid input
        }
	}
		
	/**
	 * The addStockToInventory method can be used by the user to add more stock to the inventory, for example, if 
	 * a certain item is running low or if more stock or new stock has come in to the store. The method first 
	 * asks the user if they will be adding stock to an existing product, or creating a new item. If adding to existing
	 * stock, the user is prompted to enter the name of the item, which is checked against the catalogue, and then
	 * added to the inventory with the updated quantity. If adding a new item, the user must first choose if the item
	 * is a clothing product or shoe product, which then calls the appropriate helper method to obtain the new
	 * item's details, and add it to the inventory with the specified stock.
	 */
	private static void addStockToInventory() {
		System.out.println("\n---------Add/Re-stock Inventory---------");
		System.out.println("Do you want to (1) Re-stock an existing item or (2) Add a new item? (Enter 1 or 2, or 0 to cancel): ");
		int choice = getIntegerInput();
		scanner.nextLine();

		if (choice == 0) { // Cancel operation
			System.out.println("Stock operation cancelled.");
			return;
		}

		if (choice == 1) { // Re-stock existing item
			myInventory.displayInventory();
			System.out.println("\nEnter the name of the item to restock: ");
			String itemName = scanner.nextLine().trim();
			
			Saleable selectedItem = findItemInCatalogue(itemName);
			if (selectedItem == null) {
				System.out.println("\nItem not found in catalogue.");
				return;
			}
			// Make sure the item being added is a product (not a service)
			if (!(selectedItem instanceof Product)) {
				System.out.println("Error: Only physical products can have stock added to inventory. '" + selectedItem.getName() + "' is a service.");
				return;
			}
			
			Product productToRestock = (Product) selectedItem;
			
			System.out.println("\nEnter quantity to add: ");
			int quantity = getPositiveIntegerInput();
			if (quantity <= 0) {
				System.out.println("\nQuantity to add must be positive.");
				return;
			}
			
			myInventory.addStock(productToRestock, quantity);
			System.out.println("Successfully added " + quantity + " units of " + productToRestock.getName() + ".");
			System.out.println("New stock for " + productToRestock.getName() + ": " + myInventory.getQuantity(productToRestock));

		} else if (choice == 2) { // Add a new item
			System.out.println("\n---------Add New Product---------");
			System.out.println("What type of product do you want to add? (1) Clothing or (2) Shoes (Enter 1 or 2, or 0 to cancel): ");
			int productTypeChoice = getIntegerInput();
			scanner.nextLine();
			
			Product newProduct = null;
			if (productTypeChoice == 1) { // Add a new clothing product
				newProduct = getNewClothingDetails();
			} else if (productTypeChoice == 2) { // Add a new shoes product
				newProduct = getNewShoesDetails();
			} else if (productTypeChoice == 0) { // Cancel the operation
				System.out.println("New product creation cancelled.");
				return;
			} else {
				System.out.println("Invalid product type choice.");
				return;
			}

			if (newProduct != null) {
				System.out.println("\nEnter initial stock quantity for " + newProduct.getName() + ": ");
				int initialQuantity = getPositiveIntegerInput();
				if (initialQuantity <= 0) {
					System.out.println("\nInitial quantity must be positive. New product not added.");
					return;
				}
				
				myCatalogue.addItem(newProduct); // Add to catalogue
				myInventory.addStock(newProduct, initialQuantity); // Add to inventory
				System.out.println("Successfully added new product: " + newProduct.getName() + " to catalogue and inventory with " + initialQuantity + " units.");
			} else {
				System.out.println("New product creation failed or cancelled due to invalid input.");
			}
		} else {
			System.out.println("Invalid choice for stock operation.");
		}
	}
	
	/**
	 * The getNewClothingDetails method is a helper method to handle entering new data about clothing products being
	 * added to the inventory. This method is used when the user adds new stock of a brand new clothing product. The 
	 * method will take user input to gather details about the name, price, weight, size, and colour type of the
	 * new clothing product to fulfil all the requirements of the Shoes() constructor.
	 * @return Returns a new clothing product instance.
	 */
	private static Product getNewClothingDetails() {
		System.out.println("\n---------Enter Clothing details---------");
		System.out.println("Enter name(e.g. 'Striped T-shirt'):");
		String name = scanner.nextLine().trim();
		if (name.isEmpty()) {
			System.out.println("Name cannot be empty.");
			return null;
		}
		
		System.out.println("Enter price in pennies(e.g. 2500 for £25.00)");
		int price = getPositiveIntegerInput();
		if (price == -1) {
			return null;
		}
		
		System.out.println("Enter weight in grams (e.g. 200)");
		int weight = getPositiveIntegerInput();
		if (weight == -1) {
			return null;
		}
		
		System.out.println("Enter size (UK women's numerical sizes - e.g. 10)");
		int size = getPositiveIntegerInput();
		scanner.nextLine();
		if (size == -1) {
			return null;
		}
		
		System.out.println("Enter colour (e.g. 'red')");
		String colour = scanner.nextLine().trim();
		if (colour.isEmpty()) {
			System.out.println("Colour cannot be empty.");
			return null;
		}
		
		return new Clothing(price, weight, name, size, colour);
	}
	
	/**
	 * The getNewShoesDetails method is a helper method to handle entering new data about Shoe products being
	 * added to the inventory. This method is used when the user adds new stock of a brand new shoe product. The 
	 * method will take user input to gather details about the name, price, weight, size, and heel type of the
	 * new shoes product to fulfil all the requirements of the Shoes() constructor.
	 * @return Returns a new Shoes product instance.
	 */
	private static Product getNewShoesDetails() {
		System.out.println("\n---------Enter Shoes Details---------");
		System.out.println("Enter name (e.g. 'Open toe heels'");
		String name = scanner.nextLine().trim();
		if (name.isEmpty()) {
			System.out.println("Name cannot be empty");
			return null;
		}
		
		System.out.println("Enter the price in pennies (e.g. 3500 for £35.00)");
		int price = getPositiveIntegerInput();
		if (price == -1) {
			return null;
		}
		
		System.out.println("Enter the weight in grams (e.g. 500)");
		int weight = getPositiveIntegerInput();
		if (weight == -1) {
			return null;
		}
		
		System.out.println("Enter size in European women's sizes (e.g. 39)");
		int size = getPositiveIntegerInput();
		scanner.nextLine();
		if (size == -1) {
			return null;
		}
		
		System.out.println("Enter heel type (e.g. flat, kitten, wedge, high)");
		String heel = scanner.nextLine().trim();
		if (heel.isEmpty()) {
			System.out.println("Heel type cannot be empty");
			return null;
		}
		
		return new Shoes(price, weight, name, size, heel);
	}
		
	
	/**
	 * The makePurchase method handles all purchase transactions by the user in the interface. The method first uses
	 * selectCustomer method to either create a new customer ID or retrieve an existing one. The user may then enter
	 * an item to purchase by typing in the name as seen in the catalogue. If the entered name does not match any item
	 * in the catalogue, an order is not processed. If the item name matches, the user is prompted to enter the quantity
	 * they wish to purchase. The method makes sure that this quantity is a positive number. The processOrder method
	 * is then called, which will check the inventory to confirm enough stock is available to make the purchase.
	 */
	private static void makePurchase() {
		System.out.println("\n---------Make a Purchase---------");
		Customer currentCustomer = selectCustomer(true); // User allowed to create a new customer ID when making a purchase
		if (currentCustomer == null) {
			return;
		}
		
		myCatalogue.displayCatalogue();
		System.out.println("\nEnter the name of the item you wish to purchase(e.g. 'Black T-shirt', 'Next Day Delivery')");
		String itemName = scanner.nextLine().trim();
	
		Saleable selectedItem = findItemInCatalogue(itemName); // Checks entered name matched item in catalogue
		if (selectedItem == null) {
			System.out.println("\nItem not found in catalogue.");
			return;
		}
		
		System.out.println("\nEnter quantity: ");
		int quantity = getPositiveIntegerInput();
		if (quantity <= 0) {
			System.out.println("\nPurchase quantity must be positive.");
			return;
		}
		
		order.processOrder(currentCustomer, selectedItem, quantity, myInventory);
	
	}
	
	/**
	 * The processRefund method handles all refund processes by the user in the interface. The method first checks who
	 * the customer is, then retrieves their past transactions. If no purchase transaction history for this customer
	 * can be found, then a refund is not processed. If a purchase history is found, the customer is prompted to
	 * enter which of their purchased items they wish to refund. If the entered product is not present in their purchase 
	 * history or does not exist in the catalogue, the refund will not be processed. If the product to be refunded 
	 * exists in the customer purchase history and in the catalogue, the user will be prompted to enter the quantity
	 * they wish to refund. If the quantity to be refunded is more than the quantity purchased, the refund will not be
	 * processed. If the quantity is less than or equal to the purchased amount, the refund will be processed.
	 * Standard delivery fee is non-refundable and not included in the refund value calculation.
	 */
	private static void processRefund() {
		System.out.println("\n---------Process a Refund---------");
		Customer currentCustomer = selectCustomer(false); // No option to create new customer ID when requesting refund
		if (currentCustomer == null) {
			return;
		}
		
		System.out.println("\nCustomer " + currentCustomer.getCustomerID() + "'s Past Transactions:");
		// Check if customer has made any transactions
		if (currentCustomer.getTransactions().isEmpty()) {
			System.out.println("\nNo transactions found for this customer.");
			System.out.println("\nNo purchase history for this customer ID. Refund not processed.");
		}
		// Display all of the customer's past transactions
		currentCustomer.getTransactions().forEach(System.out::println);
		// Prompt user to enter the item to be refunded
		System.out.println("\nEnter the name of the item to refund: ");
		String itemName = scanner.nextLine().trim();
		// Check if the item exists in the catalogue
		Saleable itemToRefund = findItemInCatalogue(itemName);
		if (itemToRefund == null) {
			System.out.println("\nItem not found in catalogue. Cannot process refund.");
			return;
		}
		
		System.out.println("\nEnter quantity to refund: ");
		int quantity = getPositiveIntegerInput(); 
		if (quantity <= 0) {
			System.out.println("\nRefund quantity must be positive.");
			return;
		}
		
		int purchasedQuantity = 0;
		for (Transaction t : currentCustomer.getTransactions()) {
			// Checks the quantity of the item purchased
			if (t instanceof Purchase) { // Checks that the past transaction is a purchase (not another refund)
				Purchase p = (Purchase) t;
				if (p.getItem().getName().equalsIgnoreCase(itemToRefund.getName())) {
					purchasedQuantity += p.getQuantity();
				}
			}
		}
		
		if (purchasedQuantity < quantity) {
			// Prevents user from refunding a larger quantity of items than the customer purchased
			System.out.println("\nRefund failed: Customer has purchased only " + purchasedQuantity + " units of " + itemToRefund.getName() + ".");
			System.out.println("\nCannot refund " + quantity + " " + itemToRefund.getName());
			return;
		}
		
		System.out.println("\nEnter reason for refund: ");
		scanner.nextLine();
		String reason = scanner.nextLine();
		
		int refundValue = itemToRefund.getPrice() * quantity;
		// Processes the refund using the processRefund() method
		order.processRefund(currentCustomer, itemToRefund, quantity, myInventory, refundValue, reason);
	}
	
	/**
	 * The selectCustomer method handles the customer interaction in the transaction methods. It provides the
	 * user with the option to enter an existing customer ID or create a new unique customer ID using UUID. They
	 * also have the option to cancel (if they don't have access to their already existing ID at that moment).
	 * @param allowNewCustomer The method is passed either true or false. If true (in purchase method); the customer 
	 * is prompted to cancel, make a new ID, or enter an existing ID. If false (in refund method); the customer is not 
	 * given the option to make a new ID, as only existing customers may process a refund.
	 * @return If customer decides to cancel; returns null. If customer creates a new ID; returns a new customer
	 * instance with a new random UUID. If customer enters an existing ID number; returns existing customer instance.
	 * If entered ID does not exist; returns null.
	 */
	private static Customer selectCustomer(boolean allowNewCustomer) {
		String promptMessage = "\nEnter Customer ID";
		if (allowNewCustomer) { // When boolean allowNewCustomer is true, create new ID prompt is included 
			promptMessage += ", enter 'new' to create a new customer";
		}
		promptMessage += ", or 'cancel' to return to main menu: ";
		System.out.println(promptMessage);

		String customerIdInput = scanner.nextLine().trim(); // Read input as String and remove whitespace

        if (customerIdInput.equalsIgnoreCase("cancel")) {
            return null; // User cancelled
        } else if (allowNewCustomer && customerIdInput.equalsIgnoreCase("new")) {
            // Create new customer with UUID
            String newId = UUID.randomUUID().toString();
            Customer newCustomer = new Customer(newId);
            customers.put(newId, newCustomer);
            System.out.println("\nNew customer created with ID: " + newId);
            return newCustomer;
        } else {
            // Select existing customer by the provided String ID
            String customerId = customerIdInput; // Use the input directly as the ID
            if (customers.containsKey(customerId)) {
                return customers.get(customerId);
            } else {
                System.out.println("\nCustomer with ID " + customerId + " not found.");
                return null;
			}
		}
	}
	
	/**
	 * The findItemInCatalogue method handles user input relating to items to purchase, refund, or re-stock. The
	 * method checks that the user input matches an item in the catalogue before continuing with the purchase, 
	 * refund, or re-stock process.
	 * @param name The name of the item the user wishes to purchase, refund, or re-stock.
	 * @return If the user input matches an item in the catalogue; returns item. Otherwise, returns null.
	 */
	private static Saleable findItemInCatalogue(String name) {
		for (Saleable item : myCatalogue.getItems()) {
			if (item.getName().equalsIgnoreCase(name)) {
				return item;
			}
		}
		return null;
	}
	
	/**
	 * The viewCustomerTransactions method allows the user to view all transactions (purchases and refunds)
	 * associated with the entered customer ID number. It displays details of the transactions and the total
	 * cost of all transactions made by the customer.
	 */
	public static void viewCustomerTransactions() {
		System.out.println("\n---------View Customer Transactions---------");
		Customer currentCustomer = selectCustomer(false); 
		// false parameter in selectCustomer() means user will not be prompted to create a new user ID
		if (currentCustomer == null) {
			return;
		}
		
		System.out.println("\nTransactions for Customer ID: " + currentCustomer.getCustomerID());
		if (currentCustomer.getTransactions().isEmpty()) {
			System.out.println("\nNo transactions associated with this customer ID.");
		} else {
			currentCustomer.getTransactions().forEach(System.out::println);;
			System.out.println("\nCurrent Total: £" + (double)currentCustomer.getTotal() / 100.0);
		}
	}
	
	/**
	 * The getIntegerInput method ensures that the user enters a whole number when prompted by the interface.
	 * It handles any invalid input, preventing system errors.
	 * @return If user input is invalid, i.e. not an integer; returns error message prompting user to enter
	 * a whole number. Otherwise, returns user input.
	 */
	private static int getIntegerInput() {
        if (scanner.hasNextInt()) {
        	int input = scanner.nextInt();
        	return input;
        } else {
        	System.out.println("\nInvalid input. Please enter a whole number.");
        	scanner.nextLine();
        	return -1;
        }
    }
	
	/**
	 * The getPositiveIntegerInput method ensures that only a positive integer value is entered by the user.
	 * Negative values will result in a message instructing the user to enter a positive number.
	 * @return Returns sentinel value '-1' if user input is not a positive, whole number. If user input is valid,
	 * returns user input.
	 */
	private static int getPositiveIntegerInput() {
        int input = getIntegerInput();
        if (input <= 0) {
            System.out.println("\nInput must be a positive number.");
            return -1; // Sentinel value for invalid input
        }
        return input;
    }
}


