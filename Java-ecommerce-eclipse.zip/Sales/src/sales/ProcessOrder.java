package sales;

import management.Inventory;
import saleable.Product;
import saleable.Saleable;
import transaction.Purchase;
import transaction.Refund;

/**
 * The class ProcessOrder represents an ordering system that processes purchases and refunds.
 */
public class ProcessOrder {
	
	/**
	 * Constructs a new `ProcessOrder` instance.
	 */
	public ProcessOrder() {	
	}

	/**
	 * The method processOrder takes parameters for customer, item, quantity, and stock. The
	 * method checks if the order is for a Product or a service. If the order is for a Product,
	 * the method then checks if the requested quantity of the product is in stock. If so, the
	 * order is processed by removing the quantity of that product from the inventory, and 
	 * calling a purchase transaction. If the requested quantity is unavailable then it prints
	 * out that the order has failed due to insufficient stock. Otherwise, if the item is not
	 * a Product, and therefore a Service, the order is processed with a transaction without
	 * checking stock.
	 * @param customer The customer making the order.
	 * @param item The item being ordered.
	 * @param quantity The quantity of the item being ordered.
	 * @param stock The inventory to be checked for stock.
	 * @return Returns true if the Product is in stock, or the order is for a Service. Returns 
	 * false if the requested quantity of Product is out of stock.
	 */
	public boolean processOrder(Customer customer, Saleable item, int quantity, Inventory stock) {
		if (item instanceof Product) {
			Product product = (Product) item;
			if (stock.isAvailable(product, quantity)) {
				stock.removeStock(product, quantity);
				Purchase p = new Purchase(item, quantity);
				customer.transact(p);
				System.out.println("Order successful. Total cost: £" + (double)customer.getTotal() / 100);
				return true;
			} else {
				System.out.println("Order failed. Item: " + product.getName() + ", Quantity: " + quantity + ", is not available. Current stock: " + stock.getQuantity(product));
				return false;
			}
		} else {
		Purchase p = new Purchase(item, quantity);
		customer.transact(p);
		System.out.println("Order successful. Total cost: £" + (double)customer.getTotal() / 100);
		return true;
		}
	}
	
	/**
	 * The method processRefund takes parameters for customer, item, quantity, stock, value and
	 * reason for refund. The method first checks if the item being refunded is a Product,
	 * and then adds the refunded quantity of the Product to the inventory. Then a refund
	 * transaction is processed.
	 * @param customer The customer requesting a refund.
	 * @param item The Product or Service to be refunded.
	 * @param quantity The quantity of the item being refunded.
	 * @param stock The inventory the returned Product should be added to.
	 * @param value The value of the item being refunded.
	 * @param reason The reason for the refund request.
	 */
	public void processRefund(Customer customer, Saleable item, int quantity, Inventory stock, int value, String reason) {
		if (item instanceof Product) {
			Product product = (Product) item;
			stock.addStock(product, quantity);
			System.out.println("Stock for " + product.getName() + " increased by " + quantity + " due to refund.");
		}
			Refund r = new Refund(value, reason);
			customer.transact(r);
			System.out.println("Refund of " + item.getName() + " for £" + (double)value / 100 + " successfully processed.");
	}
	
}
