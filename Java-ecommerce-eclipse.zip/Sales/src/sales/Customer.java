package sales;

import java.util.ArrayList;
import java.util.List;

import transaction.Transaction;

/**
 * This class represents a customer.
 */
public class Customer {
	
	/**
	 * The unique identification number for the customer.
	 */
	private String customerID;
	/**
	 * A list storing all purchase and refund transactions by the customer.
	 */
	private List<Transaction> transactions;
	
	/**
	 * The constructor initialises a customer object with a customer ID number and a
	 * new ArrayList of transactions.
	 * @param customerID The customer ID number to be linked to the customer.
	 */
	public Customer(String customerID) {
		this.customerID = customerID;
		this.transactions = new ArrayList<Transaction>();
	}
	
	/**
	 * The method transact adds a new transaction of either purchase or refund to the 
	 * transactions ArrayList.
	 * @param transaction The purchase or refund transaction.
	 */
	public void transact(Transaction transaction) {
		transactions.add(transaction);
	}
	
	/**
	 * The getTotal method returns the total transaction cost incurred by the customer.
	 * This total may be a positive or a negative.
	 * @return Returns the sum of all transactions for the customer.
	 */
	public int getTotal() {
		int total = 0;
		for(int i = 0; i < transactions.size(); i++) {
			total += transactions.get(i).getValue();
		}
		return total;
	}

	/**
	 * The getCustomerID method returns the customer ID number.
	 * @return Returns the customer ID number.
	 */
	public String getCustomerID() {
		return customerID;
	}
	
	/**
	 * The method getTransactions returns all the transaction details for the customer.
	 * @return Returns all the transaction details for the customer.
	 */
	public List<Transaction> getTransactions() {
		return transactions;
	}

}

