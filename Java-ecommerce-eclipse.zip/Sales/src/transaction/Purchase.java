package transaction;

import saleable.Product;
import saleable.Saleable;

/**
 * This class represents a purchase transaction.
 */
public class Purchase extends Transaction {

	/**
	 * The item purchased in the transaction.
	 */
	private Saleable item;
	/**
	 * The quantity of the item purchased.
	 */
	private int quantity;
	
	/**
	 * The constructor initialises a Purchase object with parameters for item and quantity.
	 * @param item The item to be purchased.
	 * @param quantity The quantity of the purchase item requested.
	 */
	public Purchase(Saleable item, int quantity) {
		super((item.getPrice() * quantity) + ((item instanceof Product) ? ((Product) item).calculateDelivery() : 0));
		this.item = item;
		this.quantity = quantity;
	}
	
	/**
	 * The Override toString method returns the purchase information: quantity, name, and 
	 * value, returned as their true values rather than their hash code.
	 */
	@Override
	public String toString() {
		return "Purchase of " + quantity + " " + item.getName() + " for £" + (getValue() / 100.0) + " incl. delivery";
	}
	
	/**
	 * The getItem method returns the item being purchased.
	 * @return Returns the item being purchased.
	 */
	public Saleable getItem() {
		return item;
	}

	/**
	 * The method getQuantity returns the quantity being purchased.
	 * @return Returns the quantity being purchased.
	 */
	public int getQuantity() {
		return quantity;
	}

}
