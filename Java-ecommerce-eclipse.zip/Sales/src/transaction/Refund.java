package transaction;

/**
 * This class represents a refund transaction.
 */
public class Refund extends Transaction {
	
	/**
	 * The reason for the refund.
	 */
	private String reason;
	
	/**
	 * The constructor initialises a Refund object with a value and a reason.
	 * @param value The value of the refund transaction.
	 * @param reason The reason for the refund.
	 */
	public Refund(int value, String reason) {
		super(-value);
		this.reason = reason;
	}
	
	/**
	 * The Override toString method returns the refund information: the value and reason for
	 * refund are returned as their true values rather than their hash code.
	 */
	@Override
	public String toString() {
		return "Refund of £" + (double)(-getValue() / 100.0) + " for reason: '" + reason + "' (delivery fee non refundable)";
	}

	/**
	 * The getValue method returns the value of the refund.
	 * @return Returns the value of the refund.
	 */
	public int getValue() {
		return this.value;
	}
	
	/**
	 * The getReason method returns the reason for the refund request.
	 * @return Returns the reason for the refund.
	 */
	public String getReason() {
		return this.reason;
	}

}
