package transaction;

/**
 * This class represents a transaction. 
 */
public abstract class Transaction {

	/**
	 * The value of the transaction in pennies.
	 * The value can be positive for purchases or negative for refunds.
	 */
	protected int value;
	
	/**
	 * The constructor initialises a transaction object with a value.
	 * @param value The value of the transaction.
	 */
	public Transaction(int value) {
		this.value = value;
	}
	
	/**
	 * The getValue method returns the value of the transaction.
	 * @return Returns the value of the transaction.
	 */
	public int getValue() {
		return value;
	}
	
}
